const { supabaseAdmin } = require('../config/supabase');
require('dotenv').config();

/**
 * Xác thực access_token của Supabase Auth qua GoTrue.
 * Gắn req.user: sub (PUBLIC users.id, dùng cho FK), auth_id (auth.users.id), email, role.
 */
const authenticate = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Không có token xác thực' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const { data: authData, error: authErr } = await supabaseAdmin.auth.getUser(token);
    if (authErr || !authData?.user) {
      return res.status(401).json({ error: 'Token không hợp lệ hoặc đã hết hạn' });
    }
    const u = authData.user;
    // Lookup public.users theo email — lấy ID khớp FK
    const { data: profile } = await supabaseAdmin
      .from('users')
      .select('id, role')
      .eq('email', u.email)
      .maybeSingle();

    if (!profile) {
      return res.status(403).json({ error: 'Tài khoản không có hồ sơ trong hệ thống. Liên hệ admin.' });
    }

    req.user = {
      sub:     profile.id,   // public.users.id — dùng cho FK
      auth_id: u.id,         // auth.users.id — phòng khi cần
      email:   u.email,
      role:    profile.role,
    };
    next();
  } catch {
    return res.status(401).json({ error: 'Token không hợp lệ hoặc đã hết hạn' });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Bạn không có quyền truy cập' });
  }
  next();
};

module.exports = { authenticate, authorize };
